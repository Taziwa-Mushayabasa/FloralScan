package com.example.myfloralscanapp; // Replace with your actual package name

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.squareup.picasso.Picasso;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;

public class ImageDisplayActivity extends AppCompatActivity {

    private ImageView uploadedImage;
    private TextView plantNameTextView;
    private TextView plantDescriptionTextView;

    private void setupBottomNavigationView() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.nav_view); // Adjust the ID if different
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.navigation_dashboard) {
                Intent intentDashboard = new Intent(ImageDisplayActivity.this, ImageDisplayActivity.class);
                startActivity(intentDashboard);
                return true;
            }
            // Other cases
            return false;
        });
        bottomNavigationView.setSelectedItemId(R.id.navigation_home);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_display); // Make sure you have a layout file called activity_image_display

        uploadedImage = findViewById(R.id.uploadedImage); // Replace with your actual ImageView id
        plantNameTextView = findViewById(R.id.plantNameTextView); // Replace with your actual TextView id for plant name
        plantDescriptionTextView = findViewById(R.id.plantDescriptionTextView); // Replace with your actual TextView id for plant description

        setupBottomNavigationView();
        getPlantDetailsFromLambda();
    }

    private void getPlantDetailsFromLambda() {
        OkHttpClient client = new OkHttpClient();
        String lambdaEndpoint = "https://utf5cdwynh.execute-api.eu-west-1.amazonaws.com/PlantDefaultStage/flowers"; // Replace with your actual API Gateway endpoint

        Request request = new Request.Builder()
                .url(lambdaEndpoint)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                Log.e("LambdaAPI", "Network request failed: " + e.getMessage());
                // Handle failure, possibly update UI to notify the user
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    Log.d("LambdaResponse", "Successful response data: " + responseData);
                    runOnUiThread(() -> updateUI(responseData));
                } else {
                    Log.e("LambdaResponse", "Unsuccessful response with status code: " + response.code() + " and message: " + response.message());
                    String errorBody = response.body().string();
                    Log.e("LambdaResponse", "Unsuccessful response body: " + errorBody);
                    // Handle non-successful response, possibly update UI to notify the user
                }
            }
        });
    }

    private void updateUI(String jsonData) {
        try {
            JSONObject jsonObject = new JSONObject(jsonData);

            // Parse plant details
            final String plantName = jsonObject.optString("common_name", "Name not available");
            final String description = jsonObject.optString("description", "Description not available");

            // Update UI with plant details
            plantNameTextView.setText(plantName);
            plantDescriptionTextView.setText(description);


            String imageUrl = jsonObject.optString("image_url", "");
            if (!imageUrl.isEmpty()) {
                // Load the image using Picasso
                Picasso.get().load(imageUrl).placeholder(R.drawable.placeholder_flower).into(uploadedImage);
            } else {

                uploadedImage.setImageResource(R.drawable.placeholder_flower); // Use an actual placeholder resource
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Log.e("UpdateUI", "JSONException: " + e.getMessage());
            // Handle exception, possibly update UI to notify the user
        }
    }

}